# Assets Package Definition
