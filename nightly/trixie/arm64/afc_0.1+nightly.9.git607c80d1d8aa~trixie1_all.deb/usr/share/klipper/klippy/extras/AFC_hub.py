# Armored Turtle Automated Filament Changer
#
# Copyright (C) 2024-2026 Armored Turtle
#
# This file may be distributed under the terms of the GNU GPLv3 license.
from __future__ import annotations

import traceback

from configparser import Error as config_error
from typing import TYPE_CHECKING, Any, Dict, Optional

try: from extras.AFC_utils import ERROR_STR
except: raise config_error("Error when trying to import AFC_utils.ERROR_STR\n{trace}".format(trace=traceback.format_exc()))

try: from extras.AFC_utils import add_filament_switch
except: raise config_error(ERROR_STR.format(import_lib="AFC_utils", trace=traceback.format_exc()))

try: from extras.AFC_unit import SENSORLESS_UNITS
except: raise config_error(ERROR_STR.format(import_lib="AFC_unit", trace=traceback.format_exc()))

if TYPE_CHECKING:
    from configfile import ConfigWrapper
    from klippy import Printer
    from extras.AFC import afc
    from extras.AFC_lane import AFCLane
    from extras.AFC_unit import afcUnit

class afc_hub:
    def __init__(self, config: ConfigWrapper) -> None:
        """
        Parse hub configuration and register for klippy:connect/klippy:ready.
        Registers a filament switch sensor for physical hubs; virtual hubs
        skip that and instead derive their state from their lanes' load
        sensors (see the state property).

        :param config: Klipper config wrapper for the AFC_hub section
        """
        self.printer: Printer = config.get_printer()
        self.printer.register_event_handler("klippy:connect", self.handle_connect)
        self.printer.register_event_handler("klippy:ready", self.handle_ready)
        self.afc: afc   = self.printer.load_object(config, 'AFC')
        self.reactor    = self.printer.get_reactor()

        self.fullname: str = config.get_name()
        self.name: str     = self.fullname.split()[-1]

        self.unit: Optional[afcUnit] = None
        self.lanes: Dict[str, AFCLane] = {}
        self._state: bool = False

        self.switch_pin: Optional[str] = config.get('switch_pin', None)
        # HUB Cut variables
        # Next two variables are used in AFC
        self.hub_clear_move_dis     = config.getfloat("hub_clear_move_dis", 65)     # How far to move filament so that it's not block the hub exit
        self.afc_bowden_length      = config.getfloat("afc_bowden_length", 900)     # Length of the Bowden tube from the hub to the toolhead sensor in mm.
        self.td1_bowden_length      = config.getfloat("td1_bowden_length", self.afc_bowden_length-50)     # Length of the Bowden tube from the hub to a TD-1 device in mm.
        self.afc_unload_bowden_length= config.getfloat("afc_unload_bowden_length", self.afc_bowden_length) # Length to unload when retracting back from toolhead to hub in mm. Defaults to afc_bowden_length
        self.assisted_retract       = config.getboolean("assisted_retract", False)  # if True, retracts are assisted to prevent loose windings on the spool
        self.move_dis               = config.getfloat("move_dis", 75)               # Distance to move the filament within the hub in mm.
        # Servo settings
        self.cut                    = config.getboolean("cut", False)               # Set True if Hub cutter installed (e.g. Snappy)
        self.cut_cmd                = config.get('cut_cmd', None)                   # Macro to use for cut.
        self.cut_servo_name         = config.get('cut_servo_name', 'cut')           # Name of servo to use for cutting
        self.cut_dist               = config.getfloat("cut_dist", 50)               # How much filament to cut off (in mm).
        self.cut_clear              = config.getfloat("cut_clear", 120)             # How far the filament should retract back from the hub (in mm).
        self.cut_min_length         = config.getfloat("cut_min_length", 200)        # Minimum length of filament to cut off
        self.cut_servo_pass_angle   = config.getfloat("cut_servo_pass_angle", 0)    # Servo angle to align the Bowden tube with the hole for loading the toolhead.
        self.cut_servo_clip_angle   = config.getfloat("cut_servo_clip_angle", 160)  # Servo angle for cutting the filament.
        self.cut_servo_prep_angle   = config.getfloat("cut_servo_prep_angle", 75)   # Servo angle to prepare the filament for cutting (aligning the exit hole).
        self.cut_confirm            = config.getboolean("cut_confirm", 0)           # Set True to cut filament twice

        self.config_bowden_length   = self.afc_bowden_length                        # Used by SET_BOWDEN_LENGTH macro
        self.config_unload_bowden_length = self.afc_unload_bowden_length
        self.enable_sensors_in_gui  = config.getboolean("enable_sensors_in_gui",    self.afc.enable_sensors_in_gui) # Set to True to show hub sensor switches as filament sensor in mainsail/fluidd gui, overrides value set in AFC.cfg
        self.debounce_delay         = config.getfloat("debounce_delay",             self.afc.debounce_delay)
        self.enable_runout          = config.getboolean("enable_hub_runout",        self.afc.enable_hub_runout)
        self.use_dist_hub           = config.getboolean("use_dist_hub", False)      # Value to indicate that lanes dist_hub variable should be used instead of afc_bowden_length value. Set true when setting hub up as a virtual hub

        if (self.switch_pin
            and self.switch_pin.lower() != "virtual"):
            buttons = self.printer.load_object(config, "buttons")
            created = add_filament_switch(
                f"{self.name}_Hub",
                self.switch_pin,
                self.printer,
                self.enable_sensors_in_gui,
                self.handle_runout,
                self.enable_runout,
                self.debounce_delay,
            )
            if isinstance(created, tuple):
                self.fila, self.debounce_button = created
            else:
                self.fila = created
                self.debounce_button = None
            buttons.register_buttons([self.switch_pin], self.switch_pin_callback)

        # Adding self to AFC hubs
        self.afc.hubs[self.name]=self

    def __str__(self) -> str:
        """
        String representation of the hub, used e.g. in error messages.

        :return type: hub name
        """
        return self.name

    def is_virtual_pin(self) -> bool:
        """
        Helper method that returns true when switch_pin variable is set to "virtual", meaning
        that all load switches in a unit is the hub switch. So if one load switch it triggered
        then the "hub switch" is triggered.

        :return boolean: Returns True when switch_pin variable equals virtual
        """
        return self.switch_pin.lower() == "virtual" if self.switch_pin else False

    def handle_runout(self, eventtime: float) -> None:
        """
        Callback function for hub runout, this is different than `switch_pin_callback` function as this function
        can be delayed and is called from filament_switch_sensor class when it detects a runout event.

        Before exiting `min_event_systime` is updated as this mimics how its done in `_exec_gcode` function in RunoutHelper class
        as AFC overrides `_runout_event_handler` function with this function callback. If `min_event_systime` does not get
        updated then future switch changes will not be detected.

        :param eventtime: Event time from the button press
        """
        # Only trigger runout for the currently loaded lane (in the toolhead) if it belongs to this hub
        current_lane_name = getattr(self.afc, 'current', None)
        if current_lane_name and current_lane_name in self.lanes:
            lane = self.lanes[current_lane_name]
            lane.handle_hub_runout(sensor=self.name)
        self.fila.runout_helper.min_event_systime = self.reactor.monotonic() + self.fila.runout_helper.event_delay

    def handle_connect(self) -> None:
        """
        Handle the connection event.
        This function is called when the printer connects. It looks up AFC info
        and assigns it to the instance variable `self.AFC`.
        """
        self.gcode = self.afc.gcode
        self.reactor = self.afc.reactor

        self.printer.send_event("afc_hub:register_macros", self)

    def handle_ready(self) -> None:
        """
        Handle the klippy:ready event. Verifies that lanes using a virtual hub sensor have a
        load sensor configured, raising a config error if any sensorless lanes are missing one.
        """
        if self.is_virtual_pin():
            msg = "The following lanes need load sensors for virtual hub sensor to work correctly:"
            report_error = False
            for lane in self.lanes.values():
                if lane.unit_obj.type in SENSORLESS_UNITS:
                    continue
                if (lane.load is None
                    and lane.prep is not None):
                    report_error = True
                    msg += f"\n{lane.fullname}"

            if report_error:
                raise config_error(msg)

    @property
    def state(self) -> bool:
        """
        Returns current state of switch. If using virtual sensor returns True if any lanes load
        sensor is triggered.
        """
        state = self._state
        if self.is_virtual_pin():
            state = any(lane.raw_load_state for lane in self.lanes.values())
        return state

    def switch_pin_callback(self, eventtime: float, state: int) -> None:
        """
        Callback for the hub's physical switch pin/button, registered via
        buttons.register_buttons. Updates the raw sensor state; virtual hubs
        never register this callback since they have no pin of their own.

        :param eventtime: reactor time the sensor state changed
        :param state: 1 if the hub switch is now triggered, 0 otherwise
        """
        self._state = bool(state)

    def hub_cut(self, cur_lane: AFCLane) -> None:
        """
        Run the hub's filament-cutting sequence: feed the lane until the hub
        sensor triggers, jog back and forth to find the trigger point
        precisely, feed cut_dist past it, then cycle the cutting servo
        through its prep/clip angles (and a second confirm pass if
        cut_confirm is set) before returning to the pass-through angle and
        retracting the lane by cut_clear.

        :param cur_lane: lane object being fed into the hub for the cut
        """
        servo_string = 'SET_SERVO SERVO={servo} ANGLE={{angle}}'.format(servo=self.cut_servo_name)

        # Prep the servo for cutting.
        self.gcode.run_script_from_command(servo_string.format(angle=self.cut_servo_prep_angle))
        # Load the lane until the hub is triggered.
        while not self.state:
            cur_lane.move(self.move_dis, cur_lane.short_moves_speed, cur_lane.short_moves_accel)

        # To have an accurate reference position for `hub_cut_dist`, move back and forth in smaller steps
        # to find the point where the hub just triggers.
        while self.state:
            cur_lane.move(-10, cur_lane.short_moves_speed, cur_lane.short_moves_accel, self.assisted_retract)
        while not self.state:
            cur_lane.move(2, cur_lane.short_moves_speed, cur_lane.short_moves_accel)

        # Feed the `hub_cut_dist` amount.
        cur_lane.move(self.cut_dist, cur_lane.short_moves_speed, cur_lane.short_moves_accel)
        # Have a snooze
        self.reactor.pause(self.reactor.monotonic() + 0.5)


        # Choppy Chop
        self.gcode.run_script_from_command(servo_string.format(angle=self.cut_servo_clip_angle))
        if self.cut_confirm:
            self.reactor.pause(self.reactor.monotonic() + 0.5)
            # ReChop, To be doubly choppy sure.
            self.gcode.run_script_from_command(servo_string.format(angle=self.cut_servo_prep_angle))

            self.reactor.pause(self.reactor.monotonic() + 1)
            self.gcode.run_script_from_command(servo_string.format(angle=self.cut_servo_clip_angle))
        # Longer Snooze
        self.reactor.pause(self.reactor.monotonic() + 1)
        # Align bowden tube (reset)
        self.gcode.run_script_from_command(servo_string.format(angle=self.cut_servo_pass_angle))

        # Retract lane by `hub_cut_clear`.
        cur_lane.move(-self.cut_clear, cur_lane.short_moves_speed, cur_lane.short_moves_accel, self.assisted_retract)

    def get_status(self, eventtime: Optional[float]=None) -> Dict[str, Any]:
        """
        Build the status dict reported for this hub over Klipper's webhooks
        API.

        :param eventtime: reactor time of the status request, unused
        :return type: hub state and its cut/bowden-length settings
        """
        self.response: Dict[str, Any] = {}
        self.response['state'] = bool(self.state)
        self.response['cut'] = self.cut
        self.response['cut_cmd'] = self.cut_cmd
        self.response['cut_dist'] = self.cut_dist
        self.response['cut_clear'] = self.cut_clear
        self.response['cut_min_length'] = self.cut_min_length
        self.response['cut_servo_pass_angle'] = self.cut_servo_pass_angle
        self.response['cut_servo_clip_angle'] = self.cut_servo_clip_angle
        self.response['cut_servo_prep_angle'] = self.cut_servo_prep_angle
        self.response['lanes'] = [lane.name for lane in self.lanes.values()]
        self.response['afc_bowden_length'] = self.afc_bowden_length

        return self.response

def load_config_prefix(config: ConfigWrapper) -> afc_hub:
    """
    Klipper config entry point for AFC_hub <name> sections.

    :param config: Klipper config wrapper for the AFC_hub <name> section
    :return type: afc_hub instance to register with the printer
    """
    return afc_hub(config)