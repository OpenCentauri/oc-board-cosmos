# Chipsea CS1237 support
#
# Copyright (C) 2026  Xiaoyue Cui <2508041672@qq.com>
#
# This file may be distributed under the terms of the GNU GPLv3 license.
import logging

from .. import bulk_sensor

UPDATE_INTERVAL = 0.10


class CS1237:
    def __init__(self, config):
        self.printer = printer = config.get_printer()
        self.name = config.get_name().split()[-1]
        self.error_count = 0
        self._sensor_errors = {}

        rate_options = {"10": 0, "40": 1, "640": 2, "1280": 3}
        gain_options = {"1": 0, "2": 1, "64": 2, "128": 3}
        self.sps = config.getchoice(
            "sample_rate",
            {key: int(key) for key in rate_options},
            default="640",
        )
        rate = config.getchoice("sample_rate", rate_options, default="640")
        gain = config.getchoice("gain", gain_options, default="128")
        self.reference_output = config.getboolean("reference_output", True)
        ref_off = 0 if self.reference_output else 1
        self.chip_config = (ref_off << 6) | (rate << 4) | (gain << 2)

        dout_pin_name = config.get("dout_pin")
        sclk_pin_name = config.get("sclk_pin")
        ppins = printer.lookup_object("pins")
        dout_ppin = ppins.lookup_pin(dout_pin_name)
        sclk_ppin = ppins.lookup_pin(sclk_pin_name)
        self.mcu = mcu = dout_ppin["chip"]
        if sclk_ppin["chip"] is not mcu:
            raise config.error(
                "CS1237 config error: All pins must be "
                "connected to the same MCU"
            )
        self.dout_pin = dout_ppin["pin"]
        self.sclk_pin = sclk_ppin["pin"]
        self.oid = mcu.create_oid()

        chip_smooth = self.sps * UPDATE_INTERVAL * 2
        self.ffreader = bulk_sensor.FixedFreqReader(mcu, chip_smooth, "<i")
        self.batch_bulk = bulk_sensor.BatchBulkHelper(
            printer,
            self._process_batch,
            self._start_measurements,
            self._finish_measurements,
            UPDATE_INTERVAL,
        )
        self.query_cmd = None
        self.attach_probe_cmd = None
        mcu.add_config_cmd(
            "config_cs1237 oid=%d config=%d dout_pin=%s sclk_pin=%s"
            % (self.oid, self.chip_config, self.dout_pin, self.sclk_pin)
        )
        mcu.add_config_cmd(
            "query_cs1237 oid=%d rest_ticks=0" % self.oid, on_restart=True
        )
        mcu.register_config_callback(self._build_config)

    def _build_config(self):
        cmd_queue = self.mcu.alloc_command_queue()
        self.query_cmd = self.mcu.lookup_command(
            "query_cs1237 oid=%c rest_ticks=%u", cq=cmd_queue
        )
        self.attach_probe_cmd = self.mcu.lookup_command(
            "cs1237_attach_load_cell_probe oid=%c load_cell_probe_oid=%c",
            cq=cmd_queue,
        )
        self.ffreader.setup_query_command(
            "query_cs1237_status oid=%c", oid=self.oid, cq=cmd_queue
        )
        errors = self.mcu.get_enumerations().get("cs1237_error:", {})
        self._sensor_errors = {v: k for k, v in errors.items()}

    def attach_load_cell_probe(self, load_cell_probe_oid):
        self.attach_probe_cmd.send([self.oid, load_cell_probe_oid])

    def get_mcu(self):
        return self.mcu

    def get_samples_per_second(self):
        return self.sps

    def get_range(self):
        return -0x800000, 0x7FFFFF

    def get_channel_count(self):
        return 1

    def get_status(self, eventtime):
        return {
            "errors": self.error_count,
            "overflows": self.ffreader.get_total_overflows(),
            "sample_rate": self.sps,
        }

    def lookup_sensor_error(self, error_code):
        return self._sensor_errors.get(error_code, "Unknown CS1237 error")

    def add_client(self, callback):
        self.batch_bulk.add_client(callback)

    @staticmethod
    def _convert_samples(samples):
        adc_factor = 1.0 / (1 << 23)
        count = 0
        batch_errors = 0
        for ptime, value in samples:
            top_byte = (value >> 24) & 0xFF
            if top_byte != 0x00 and top_byte != 0xFF:
                batch_errors += 1
                continue
            samples[count] = (
                round(ptime, 6),
                value,
                round(value * adc_factor, 9),
            )
            count += 1
        del samples[count:]
        return batch_errors

    def _start_measurements(self):
        rest_ticks = self.mcu.seconds_to_clock(1.0 / (10.0 * self.sps))
        self.query_cmd.send([self.oid, rest_ticks])
        logging.info(
            "CS1237 starting '%s' measurements at %d SPS", self.name, self.sps
        )
        self.ffreader.note_start()

    def _finish_measurements(self):
        if self.printer.is_shutdown():
            return
        self.query_cmd.send_wait_ack([self.oid, 0])
        self.ffreader.note_end()
        logging.info("CS1237 finished '%s' measurements", self.name)

    def _process_batch(self, eventtime):
        samples, overflows = self.ffreader.pull_samples()
        batch_errors = self._convert_samples(samples)
        self.error_count += batch_errors
        return {
            "data": samples,
            "errors": batch_errors,
            "overflows": overflows,
        }


CS1237_SENSOR_TYPE = {"cs1237": CS1237}
